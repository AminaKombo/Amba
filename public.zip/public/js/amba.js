$(document).ready(function(){
    
    //alert('connect!');
    
    $('.trumbo').trumbowyg({
        btns: [
            ['viewHTML'],
            ['formatting'],
            'btnGrp-semantic',
            ['superscript', 'subscript'],
            ['link'],
            'btnGrp-justify',
            'btnGrp-lists',
            ['horizontalRule'],
            ['removeformat'],
            ['fullscreen']
        ]
    });
    
     $('.collapsible').collapsible();
    
});